import schedule
import time
import client
import random


def job():
    user_list = ['u1','u2','u3','u4','u5','u6','u7','u8']

    for i in range(len(user_list)):
        req_user = random.choice(user_list)
        res = client.make_request()
        print('I am user ' + str(req_user))
        print('Output of API is: ' + str(res))
        time.sleep(2)


schedule.every(1).seconds.do(job)

while 1:
    schedule.run_pending()
    time.sleep(3)