# README #

This is a test ping application.


**To run client simulator**

python runner.py


