import requests


def make_request():
    url = 'http://127.0.0.1:5000/ping'

    response = requests.get(url)
    output = ''
    if response.status_code == 200 and response.content:
        output = response.content
        output = output.decode()

    return output
