# README #

This is a test ping application.

### How do I get set up? ###

**Software/Package Dependencies to Deploy Test Application**

* Python 3.6
* PIP ( https://pip.pypa.io/en/stable/installing/)

**To run the server:**

python manage.py runserver 127.0.0.1:5000


**APIs exposed**

http://127.0.0.1:5000/ping
http://127.0.0.1:5000/logs


