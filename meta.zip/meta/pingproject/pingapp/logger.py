import os.path
import logging
from logging.handlers import RotatingFileHandler


class CustomLogger:

    def __init__(self):
        pass

    @staticmethod
    def create_time_rotating_logger():
        """
        :return:
        """

        root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)

        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        access_handler = RotatingFileHandler(root_path + '/logs/app.log', maxBytes=1024, backupCount=10)
        access_handler.setLevel(logging.INFO)
        access_handler.setFormatter(formatter)

        logger.addHandler(access_handler)

        return logger

