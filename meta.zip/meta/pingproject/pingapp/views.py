from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
import random
import os
from pingapp.logger import CustomLogger
import json

logger = CustomLogger.create_time_rotating_logger()

site_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
log_path = site_root + '/logs'


@api_view(['GET'])
def ping(request):
    """
    exporting data to itco tool
    :param request:
    :return: user details and error
    """
    try:
        if request.method == 'GET':
            res_list = ['error', 'success', 'info', 'debug']
            response = random.choices(res_list, weights=[0.05, 0.8, 0.1, 0.05], k=1)
            api_res = response[0]
            res_message = ''
            if api_res == 'error':
                res_message = 'Internal Server Error'
                logger.error(res_message)
            elif api_res == 'success':
                res_message = 'Fetching Users List'
                logger.info(res_message)
            elif api_res == 'info':
                res_message = 'User is trying to fetch past 1 year data'
                logger.info(res_message)
            elif api_res == 'debug':
                res_message = 'Infrastructure at peak load'
                logger.info(res_message)

            return Response(res_message)
    except Exception as e:
        logger.exception(e)
        return Response('error', status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def logs(request):
    """
    exporting data to itco tool
    :param request:
    :return: user details and error
    """
    try:
        if request.method == 'GET':
            delim = "\n"
            res_message = ''
            log_file = log_path + '/app.log'
            log_output = []
            with open(log_file) as file:
                for line in file:
                    line_list = line.split(delim)
                    log_msg = line_list[0]
                    payload = {
                        "log_message": log_msg,
                    }
                    log_output.append(payload)

            return Response(log_output)
    except Exception as e:
        logger.exception(e)
        return Response('error', status=status.HTTP_400_BAD_REQUEST)