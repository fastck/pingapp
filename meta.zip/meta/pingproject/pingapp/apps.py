from django.apps import AppConfig


class PingappConfig(AppConfig):
    name = 'pingapp'
